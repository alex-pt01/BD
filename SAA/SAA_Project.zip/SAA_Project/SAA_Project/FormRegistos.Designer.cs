﻿namespace SAA_Project
{
    partial class FormRegistos
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(FormRegistos));
            this.label8 = new System.Windows.Forms.Label();
            this.n_Alunos = new System.Windows.Forms.TextBox();
            this.label15 = new System.Windows.Forms.Label();
            this.label16 = new System.Windows.Forms.Label();
            this.labelRegistos = new System.Windows.Forms.Label();
            this.listAlunos = new System.Windows.Forms.ListBox();
            this.labelDepf = new System.Windows.Forms.Label();
            this.comboBoxDep = new System.Windows.Forms.ComboBox();
            this.comboBoxCurso = new System.Windows.Forms.ComboBox();
            this.labelcursof = new System.Windows.Forms.Label();
            this.labelturmaf = new System.Windows.Forms.Label();
            this.comboBoxTurma = new System.Windows.Forms.ComboBox();
            this.listRegistos = new System.Windows.Forms.ListBox();
            this.labelCurso = new System.Windows.Forms.Label();
            this.labelHorario = new System.Windows.Forms.Label();
            this.labelNMEC = new System.Windows.Forms.Label();
            this.labelEmail = new System.Windows.Forms.Label();
            this.idCursoAluno = new System.Windows.Forms.TextBox();
            this.idHorarioAluno = new System.Windows.Forms.TextBox();
            this.nmecAluno = new System.Windows.Forms.TextBox();
            this.emailAluno = new System.Windows.Forms.TextBox();
            this.labelNome = new System.Windows.Forms.Label();
            this.nomeAluno = new System.Windows.Forms.TextBox();
            this.notaBtn = new System.Windows.Forms.Button();
            this.faltaBtn = new System.Windows.Forms.Button();
            this.labelucadd = new System.Windows.Forms.Label();
            this.labelnotaadd = new System.Windows.Forms.Label();
            this.labelnmecadd = new System.Windows.Forms.Label();
            this.id_uc_nota = new System.Windows.Forms.TextBox();
            this.nota_Nota = new System.Windows.Forms.TextBox();
            this.NMEC_nota = new System.Windows.Forms.TextBox();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.id_uc_Registo = new System.Windows.Forms.TextBox();
            this.id_Aval_Registo = new System.Windows.Forms.TextBox();
            this.nmecRegisto = new System.Windows.Forms.TextBox();
            this.id_registo = new System.Windows.Forms.TextBox();
            this.label9 = new System.Windows.Forms.Label();
            this.label12 = new System.Windows.Forms.Label();
            this.label17 = new System.Windows.Forms.Label();
            this.label19 = new System.Windows.Forms.Label();
            this.id_nota = new System.Windows.Forms.TextBox();
            this.notaBox = new System.Windows.Forms.TextBox();
            this.label23 = new System.Windows.Forms.Label();
            this.id_falta = new System.Windows.Forms.TextBox();
            this.label11 = new System.Windows.Forms.Label();
            this.label20 = new System.Windows.Forms.Label();
            this.label18 = new System.Windows.Forms.Label();
            this.confirmBtn = new System.Windows.Forms.Button();
            this.filtros_btn = new System.Windows.Forms.Button();
            this.hideBtn = new System.Windows.Forms.Button();
            this.labelucfalta = new System.Windows.Forms.Label();
            this.labeltipofalta = new System.Windows.Forms.Label();
            this.labelnmecfalta = new System.Windows.Forms.Label();
            this.ucfalta = new System.Windows.Forms.TextBox();
            this.nmecfalta = new System.Windows.Forms.TextBox();
            this.tipoFaltaCombo = new System.Windows.Forms.ComboBox();
            this.confirmFaltaBtn = new System.Windows.Forms.Button();
            this.eliminarBtn = new System.Windows.Forms.Button();
            this.updateBtn = new System.Windows.Forms.Button();
            this.comboBoxtipoFalta = new System.Windows.Forms.ComboBox();
            this.cancelarBtn = new System.Windows.Forms.Button();
            this.confirmUpdateBtn = new System.Windows.Forms.Button();
            this.button2 = new System.Windows.Forms.Button();
            this.Login = new System.Windows.Forms.Button();
            this.NextPage = new System.Windows.Forms.Button();
            this.cancel_nota = new System.Windows.Forms.Button();
            this.cancel_falta = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Font = new System.Drawing.Font("Arial", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label8.Location = new System.Drawing.Point(130, 271);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(112, 15);
            this.label8.TabIndex = 152;
            this.label8.Text = "Numero de Alunos:";
            // 
            // n_Alunos
            // 
            this.n_Alunos.Location = new System.Drawing.Point(246, 269);
            this.n_Alunos.Name = "n_Alunos";
            this.n_Alunos.ReadOnly = true;
            this.n_Alunos.Size = new System.Drawing.Size(46, 20);
            this.n_Alunos.TabIndex = 151;
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.Font = new System.Drawing.Font("Arial", 7F);
            this.label15.Location = new System.Drawing.Point(167, 53);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(35, 13);
            this.label15.TabIndex = 150;
            this.label15.Text = "Nome";
            // 
            // label16
            // 
            this.label16.AutoSize = true;
            this.label16.Font = new System.Drawing.Font("Arial", 7F);
            this.label16.Location = new System.Drawing.Point(111, 53);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(37, 13);
            this.label16.TabIndex = 149;
            this.label16.Text = "NMEC";
            // 
            // labelRegistos
            // 
            this.labelRegistos.AutoSize = true;
            this.labelRegistos.Font = new System.Drawing.Font("Arial", 14F);
            this.labelRegistos.ForeColor = System.Drawing.Color.OrangeRed;
            this.labelRegistos.Location = new System.Drawing.Point(12, 12);
            this.labelRegistos.Name = "labelRegistos";
            this.labelRegistos.Size = new System.Drawing.Size(131, 22);
            this.labelRegistos.TabIndex = 148;
            this.labelRegistos.Text = "Lista Registos";
            // 
            // listAlunos
            // 
            this.listAlunos.FormattingEnabled = true;
            this.listAlunos.Location = new System.Drawing.Point(114, 69);
            this.listAlunos.Name = "listAlunos";
            this.listAlunos.Size = new System.Drawing.Size(213, 199);
            this.listAlunos.TabIndex = 147;
            this.listAlunos.SelectedIndexChanged += new System.EventHandler(this.listAluno_SelectedIndexChanged);
            // 
            // labelDepf
            // 
            this.labelDepf.AutoSize = true;
            this.labelDepf.Font = new System.Drawing.Font("Arial", 10F);
            this.labelDepf.Location = new System.Drawing.Point(5, 113);
            this.labelDepf.Name = "labelDepf";
            this.labelDepf.Size = new System.Drawing.Size(98, 16);
            this.labelDepf.TabIndex = 158;
            this.labelDepf.Text = "Departamento";
            this.labelDepf.Visible = false;
            // 
            // comboBoxDep
            // 
            this.comboBoxDep.FormattingEnabled = true;
            this.comboBoxDep.Location = new System.Drawing.Point(8, 132);
            this.comboBoxDep.Name = "comboBoxDep";
            this.comboBoxDep.Size = new System.Drawing.Size(91, 21);
            this.comboBoxDep.TabIndex = 157;
            this.comboBoxDep.Visible = false;
            this.comboBoxDep.SelectedIndexChanged += new System.EventHandler(this.comboBoxDep_SelectedIndexChanged);
            // 
            // comboBoxCurso
            // 
            this.comboBoxCurso.FormattingEnabled = true;
            this.comboBoxCurso.Location = new System.Drawing.Point(8, 189);
            this.comboBoxCurso.Name = "comboBoxCurso";
            this.comboBoxCurso.Size = new System.Drawing.Size(91, 21);
            this.comboBoxCurso.TabIndex = 156;
            this.comboBoxCurso.Visible = false;
            this.comboBoxCurso.SelectedIndexChanged += new System.EventHandler(this.comboBoxCurso_SelectedIndexChanged);
            // 
            // labelcursof
            // 
            this.labelcursof.AutoSize = true;
            this.labelcursof.Font = new System.Drawing.Font("Arial", 10F);
            this.labelcursof.Location = new System.Drawing.Point(0, 170);
            this.labelcursof.Name = "labelcursof";
            this.labelcursof.Size = new System.Drawing.Size(46, 16);
            this.labelcursof.TabIndex = 155;
            this.labelcursof.Text = "Curso";
            this.labelcursof.Visible = false;
            // 
            // labelturmaf
            // 
            this.labelturmaf.AutoSize = true;
            this.labelturmaf.Font = new System.Drawing.Font("Arial", 10F);
            this.labelturmaf.Location = new System.Drawing.Point(5, 228);
            this.labelturmaf.Name = "labelturmaf";
            this.labelturmaf.Size = new System.Drawing.Size(65, 16);
            this.labelturmaf.TabIndex = 154;
            this.labelturmaf.Text = "ID Turma";
            this.labelturmaf.Visible = false;
            // 
            // comboBoxTurma
            // 
            this.comboBoxTurma.FormattingEnabled = true;
            this.comboBoxTurma.Location = new System.Drawing.Point(8, 247);
            this.comboBoxTurma.Name = "comboBoxTurma";
            this.comboBoxTurma.Size = new System.Drawing.Size(91, 21);
            this.comboBoxTurma.TabIndex = 153;
            this.comboBoxTurma.Visible = false;
            this.comboBoxTurma.SelectedIndexChanged += new System.EventHandler(this.comboBoxTurma_SelectedIndexChanged);
            // 
            // listRegistos
            // 
            this.listRegistos.FormattingEnabled = true;
            this.listRegistos.Location = new System.Drawing.Point(333, 69);
            this.listRegistos.Name = "listRegistos";
            this.listRegistos.Size = new System.Drawing.Size(75, 199);
            this.listRegistos.TabIndex = 159;
            this.listRegistos.SelectedIndexChanged += new System.EventHandler(this.listRegistos_SelectedIndexChanged);
            // 
            // labelCurso
            // 
            this.labelCurso.AutoSize = true;
            this.labelCurso.Location = new System.Drawing.Point(129, 395);
            this.labelCurso.Name = "labelCurso";
            this.labelCurso.Size = new System.Drawing.Size(34, 13);
            this.labelCurso.TabIndex = 175;
            this.labelCurso.Text = "Curso";
            // 
            // labelHorario
            // 
            this.labelHorario.AutoSize = true;
            this.labelHorario.Location = new System.Drawing.Point(179, 393);
            this.labelHorario.Name = "labelHorario";
            this.labelHorario.Size = new System.Drawing.Size(41, 13);
            this.labelHorario.TabIndex = 173;
            this.labelHorario.Text = "Horario";
            // 
            // labelNMEC
            // 
            this.labelNMEC.AutoSize = true;
            this.labelNMEC.Location = new System.Drawing.Point(236, 395);
            this.labelNMEC.Name = "labelNMEC";
            this.labelNMEC.Size = new System.Drawing.Size(38, 13);
            this.labelNMEC.TabIndex = 172;
            this.labelNMEC.Text = "NMEC";
            // 
            // labelEmail
            // 
            this.labelEmail.AutoSize = true;
            this.labelEmail.Location = new System.Drawing.Point(130, 354);
            this.labelEmail.Name = "labelEmail";
            this.labelEmail.Size = new System.Drawing.Size(32, 13);
            this.labelEmail.TabIndex = 171;
            this.labelEmail.Text = "Email";
            // 
            // idCursoAluno
            // 
            this.idCursoAluno.Location = new System.Drawing.Point(132, 411);
            this.idCursoAluno.Name = "idCursoAluno";
            this.idCursoAluno.ReadOnly = true;
            this.idCursoAluno.Size = new System.Drawing.Size(45, 20);
            this.idCursoAluno.TabIndex = 166;
            // 
            // idHorarioAluno
            // 
            this.idHorarioAluno.Location = new System.Drawing.Point(183, 411);
            this.idHorarioAluno.Name = "idHorarioAluno";
            this.idHorarioAluno.ReadOnly = true;
            this.idHorarioAluno.Size = new System.Drawing.Size(50, 20);
            this.idHorarioAluno.TabIndex = 164;
            // 
            // nmecAluno
            // 
            this.nmecAluno.Location = new System.Drawing.Point(239, 411);
            this.nmecAluno.Name = "nmecAluno";
            this.nmecAluno.ReadOnly = true;
            this.nmecAluno.Size = new System.Drawing.Size(56, 20);
            this.nmecAluno.TabIndex = 163;
            // 
            // emailAluno
            // 
            this.emailAluno.Location = new System.Drawing.Point(133, 370);
            this.emailAluno.Name = "emailAluno";
            this.emailAluno.ReadOnly = true;
            this.emailAluno.Size = new System.Drawing.Size(162, 20);
            this.emailAluno.TabIndex = 162;
            // 
            // labelNome
            // 
            this.labelNome.AutoSize = true;
            this.labelNome.Font = new System.Drawing.Font("Arial", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelNome.Location = new System.Drawing.Point(130, 307);
            this.labelNome.Name = "labelNome";
            this.labelNome.Size = new System.Drawing.Size(47, 17);
            this.labelNome.TabIndex = 161;
            this.labelNome.Text = "Nome";
            // 
            // nomeAluno
            // 
            this.nomeAluno.Location = new System.Drawing.Point(133, 327);
            this.nomeAluno.Name = "nomeAluno";
            this.nomeAluno.ReadOnly = true;
            this.nomeAluno.Size = new System.Drawing.Size(162, 20);
            this.nomeAluno.TabIndex = 160;
            // 
            // notaBtn
            // 
            this.notaBtn.Font = new System.Drawing.Font("Arial", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.notaBtn.Location = new System.Drawing.Point(375, 333);
            this.notaBtn.Name = "notaBtn";
            this.notaBtn.Size = new System.Drawing.Size(90, 28);
            this.notaBtn.TabIndex = 176;
            this.notaBtn.Text = "Adicionar Nota";
            this.notaBtn.UseVisualStyleBackColor = true;
            this.notaBtn.Click += new System.EventHandler(this.confirmBtn2_Click);
            // 
            // faltaBtn
            // 
            this.faltaBtn.Font = new System.Drawing.Font("Arial", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.faltaBtn.Location = new System.Drawing.Point(375, 378);
            this.faltaBtn.Name = "faltaBtn";
            this.faltaBtn.Size = new System.Drawing.Size(90, 28);
            this.faltaBtn.TabIndex = 177;
            this.faltaBtn.Text = "Adicionar Falta";
            this.faltaBtn.UseVisualStyleBackColor = true;
            this.faltaBtn.Click += new System.EventHandler(this.button2_Click);
            // 
            // labelucadd
            // 
            this.labelucadd.AutoSize = true;
            this.labelucadd.Location = new System.Drawing.Point(543, 321);
            this.labelucadd.Name = "labelucadd";
            this.labelucadd.Size = new System.Drawing.Size(36, 13);
            this.labelucadd.TabIndex = 183;
            this.labelucadd.Text = "ID UC";
            this.labelucadd.Visible = false;
            // 
            // labelnotaadd
            // 
            this.labelnotaadd.AutoSize = true;
            this.labelnotaadd.Location = new System.Drawing.Point(597, 321);
            this.labelnotaadd.Name = "labelnotaadd";
            this.labelnotaadd.Size = new System.Drawing.Size(30, 13);
            this.labelnotaadd.TabIndex = 182;
            this.labelnotaadd.Text = "Nota";
            this.labelnotaadd.Visible = false;
            // 
            // labelnmecadd
            // 
            this.labelnmecadd.AutoSize = true;
            this.labelnmecadd.Location = new System.Drawing.Point(481, 321);
            this.labelnmecadd.Name = "labelnmecadd";
            this.labelnmecadd.Size = new System.Drawing.Size(38, 13);
            this.labelnmecadd.TabIndex = 181;
            this.labelnmecadd.Text = "NMEC";
            this.labelnmecadd.Visible = false;
            // 
            // id_uc_nota
            // 
            this.id_uc_nota.Location = new System.Drawing.Point(546, 337);
            this.id_uc_nota.Name = "id_uc_nota";
            this.id_uc_nota.ReadOnly = true;
            this.id_uc_nota.Size = new System.Drawing.Size(45, 20);
            this.id_uc_nota.TabIndex = 180;
            this.id_uc_nota.Visible = false;
            // 
            // nota_Nota
            // 
            this.nota_Nota.Location = new System.Drawing.Point(597, 337);
            this.nota_Nota.Name = "nota_Nota";
            this.nota_Nota.ReadOnly = true;
            this.nota_Nota.Size = new System.Drawing.Size(91, 20);
            this.nota_Nota.TabIndex = 179;
            this.nota_Nota.Visible = false;
            // 
            // NMEC_nota
            // 
            this.NMEC_nota.Location = new System.Drawing.Point(484, 337);
            this.NMEC_nota.Name = "NMEC_nota";
            this.NMEC_nota.ReadOnly = true;
            this.NMEC_nota.Size = new System.Drawing.Size(56, 20);
            this.NMEC_nota.TabIndex = 178;
            this.NMEC_nota.Visible = false;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Arial", 7F);
            this.label4.Location = new System.Drawing.Point(330, 34);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(46, 13);
            this.label4.TabIndex = 184;
            this.label4.Text = "Registos";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(448, 158);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(39, 13);
            this.label5.TabIndex = 192;
            this.label5.Text = "ID_UC";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(448, 200);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(45, 13);
            this.label6.TabIndex = 191;
            this.label6.Text = "ID_Aval";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(448, 117);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(38, 13);
            this.label7.TabIndex = 190;
            this.label7.Text = "NMEC";
            // 
            // id_uc_Registo
            // 
            this.id_uc_Registo.Location = new System.Drawing.Point(451, 174);
            this.id_uc_Registo.Name = "id_uc_Registo";
            this.id_uc_Registo.ReadOnly = true;
            this.id_uc_Registo.Size = new System.Drawing.Size(56, 20);
            this.id_uc_Registo.TabIndex = 188;
            // 
            // id_Aval_Registo
            // 
            this.id_Aval_Registo.Location = new System.Drawing.Point(451, 215);
            this.id_Aval_Registo.Name = "id_Aval_Registo";
            this.id_Aval_Registo.ReadOnly = true;
            this.id_Aval_Registo.Size = new System.Drawing.Size(56, 20);
            this.id_Aval_Registo.TabIndex = 187;
            // 
            // nmecRegisto
            // 
            this.nmecRegisto.Location = new System.Drawing.Point(451, 133);
            this.nmecRegisto.Name = "nmecRegisto";
            this.nmecRegisto.ReadOnly = true;
            this.nmecRegisto.Size = new System.Drawing.Size(56, 20);
            this.nmecRegisto.TabIndex = 186;
            // 
            // id_registo
            // 
            this.id_registo.Location = new System.Drawing.Point(451, 88);
            this.id_registo.Name = "id_registo";
            this.id_registo.ReadOnly = true;
            this.id_registo.Size = new System.Drawing.Size(56, 20);
            this.id_registo.TabIndex = 185;
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Font = new System.Drawing.Font("Arial", 7F);
            this.label9.Location = new System.Drawing.Point(110, 34);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(39, 13);
            this.label9.TabIndex = 194;
            this.label9.Text = "Alunos";
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Font = new System.Drawing.Font("Arial", 7F);
            this.label12.Location = new System.Drawing.Point(330, 53);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(17, 13);
            this.label12.TabIndex = 195;
            this.label12.Text = "ID";
            // 
            // label17
            // 
            this.label17.AutoSize = true;
            this.label17.Font = new System.Drawing.Font("Arial", 7F);
            this.label17.Location = new System.Drawing.Point(372, 53);
            this.label17.Name = "label17";
            this.label17.Size = new System.Drawing.Size(21, 13);
            this.label17.TabIndex = 196;
            this.label17.Text = "UC";
            // 
            // label19
            // 
            this.label19.AutoSize = true;
            this.label19.Location = new System.Drawing.Point(560, 118);
            this.label19.Name = "label19";
            this.label19.Size = new System.Drawing.Size(30, 13);
            this.label19.TabIndex = 201;
            this.label19.Text = "Nota";
            // 
            // id_nota
            // 
            this.id_nota.Location = new System.Drawing.Point(560, 88);
            this.id_nota.Name = "id_nota";
            this.id_nota.ReadOnly = true;
            this.id_nota.Size = new System.Drawing.Size(56, 20);
            this.id_nota.TabIndex = 199;
            // 
            // notaBox
            // 
            this.notaBox.Location = new System.Drawing.Point(560, 134);
            this.notaBox.Name = "notaBox";
            this.notaBox.ReadOnly = true;
            this.notaBox.Size = new System.Drawing.Size(56, 20);
            this.notaBox.TabIndex = 198;
            // 
            // label23
            // 
            this.label23.AutoSize = true;
            this.label23.Location = new System.Drawing.Point(664, 117);
            this.label23.Name = "label23";
            this.label23.Size = new System.Drawing.Size(54, 13);
            this.label23.TabIndex = 206;
            this.label23.Text = "Tipo Falta";
            // 
            // id_falta
            // 
            this.id_falta.Location = new System.Drawing.Point(667, 88);
            this.id_falta.Name = "id_falta";
            this.id_falta.ReadOnly = true;
            this.id_falta.Size = new System.Drawing.Size(56, 20);
            this.id_falta.TabIndex = 205;
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Font = new System.Drawing.Font("Arial", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label11.Location = new System.Drawing.Point(448, 68);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(76, 17);
            this.label11.TabIndex = 193;
            this.label11.Text = "ID Registo";
            // 
            // label20
            // 
            this.label20.AutoSize = true;
            this.label20.Font = new System.Drawing.Font("Arial", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label20.Location = new System.Drawing.Point(557, 69);
            this.label20.Name = "label20";
            this.label20.Size = new System.Drawing.Size(56, 17);
            this.label20.TabIndex = 209;
            this.label20.Text = "ID Nota";
            // 
            // label18
            // 
            this.label18.AutoSize = true;
            this.label18.Font = new System.Drawing.Font("Arial", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label18.Location = new System.Drawing.Point(664, 68);
            this.label18.Name = "label18";
            this.label18.Size = new System.Drawing.Size(58, 17);
            this.label18.TabIndex = 210;
            this.label18.Text = "ID Falta";
            // 
            // confirmBtn
            // 
            this.confirmBtn.Font = new System.Drawing.Font("Arial", 11F);
            this.confirmBtn.Location = new System.Drawing.Point(375, 333);
            this.confirmBtn.Name = "confirmBtn";
            this.confirmBtn.Size = new System.Drawing.Size(90, 28);
            this.confirmBtn.TabIndex = 211;
            this.confirmBtn.Text = "Confirmar";
            this.confirmBtn.UseVisualStyleBackColor = true;
            this.confirmBtn.Visible = false;
            this.confirmBtn.Click += new System.EventHandler(this.notaBtn_Click);
            // 
            // filtros_btn
            // 
            this.filtros_btn.Font = new System.Drawing.Font("Arial", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.filtros_btn.Location = new System.Drawing.Point(8, 69);
            this.filtros_btn.Name = "filtros_btn";
            this.filtros_btn.Size = new System.Drawing.Size(90, 28);
            this.filtros_btn.TabIndex = 214;
            this.filtros_btn.Text = "Filtros";
            this.filtros_btn.UseVisualStyleBackColor = true;
            this.filtros_btn.Click += new System.EventHandler(this.filtros_btn_Click);
            // 
            // hideBtn
            // 
            this.hideBtn.Font = new System.Drawing.Font("Arial", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.hideBtn.Location = new System.Drawing.Point(9, 69);
            this.hideBtn.Name = "hideBtn";
            this.hideBtn.Size = new System.Drawing.Size(90, 28);
            this.hideBtn.TabIndex = 215;
            this.hideBtn.Text = "Esconder";
            this.hideBtn.UseVisualStyleBackColor = true;
            this.hideBtn.Visible = false;
            this.hideBtn.Click += new System.EventHandler(this.hideBtn_Click);
            // 
            // labelucfalta
            // 
            this.labelucfalta.AutoSize = true;
            this.labelucfalta.Location = new System.Drawing.Point(543, 370);
            this.labelucfalta.Name = "labelucfalta";
            this.labelucfalta.Size = new System.Drawing.Size(36, 13);
            this.labelucfalta.TabIndex = 221;
            this.labelucfalta.Text = "ID UC";
            this.labelucfalta.Visible = false;
            // 
            // labeltipofalta
            // 
            this.labeltipofalta.AutoSize = true;
            this.labeltipofalta.Location = new System.Drawing.Point(594, 370);
            this.labeltipofalta.Name = "labeltipofalta";
            this.labeltipofalta.Size = new System.Drawing.Size(54, 13);
            this.labeltipofalta.TabIndex = 220;
            this.labeltipofalta.Text = "Tipo Falta";
            this.labeltipofalta.Visible = false;
            // 
            // labelnmecfalta
            // 
            this.labelnmecfalta.AutoSize = true;
            this.labelnmecfalta.Location = new System.Drawing.Point(481, 370);
            this.labelnmecfalta.Name = "labelnmecfalta";
            this.labelnmecfalta.Size = new System.Drawing.Size(38, 13);
            this.labelnmecfalta.TabIndex = 219;
            this.labelnmecfalta.Text = "NMEC";
            this.labelnmecfalta.Visible = false;
            // 
            // ucfalta
            // 
            this.ucfalta.Location = new System.Drawing.Point(546, 386);
            this.ucfalta.Name = "ucfalta";
            this.ucfalta.ReadOnly = true;
            this.ucfalta.Size = new System.Drawing.Size(45, 20);
            this.ucfalta.TabIndex = 218;
            this.ucfalta.Visible = false;
            // 
            // nmecfalta
            // 
            this.nmecfalta.Location = new System.Drawing.Point(484, 386);
            this.nmecfalta.Name = "nmecfalta";
            this.nmecfalta.ReadOnly = true;
            this.nmecfalta.Size = new System.Drawing.Size(56, 20);
            this.nmecfalta.TabIndex = 216;
            this.nmecfalta.Visible = false;
            // 
            // tipoFaltaCombo
            // 
            this.tipoFaltaCombo.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.tipoFaltaCombo.FormattingEnabled = true;
            this.tipoFaltaCombo.Items.AddRange(new object[] {
            "Justificada",
            "Injustificada"});
            this.tipoFaltaCombo.Location = new System.Drawing.Point(597, 385);
            this.tipoFaltaCombo.Name = "tipoFaltaCombo";
            this.tipoFaltaCombo.Size = new System.Drawing.Size(91, 21);
            this.tipoFaltaCombo.TabIndex = 224;
            this.tipoFaltaCombo.Visible = false;
            // 
            // confirmFaltaBtn
            // 
            this.confirmFaltaBtn.Font = new System.Drawing.Font("Arial", 11F);
            this.confirmFaltaBtn.Location = new System.Drawing.Point(375, 378);
            this.confirmFaltaBtn.Name = "confirmFaltaBtn";
            this.confirmFaltaBtn.Size = new System.Drawing.Size(90, 28);
            this.confirmFaltaBtn.TabIndex = 225;
            this.confirmFaltaBtn.Text = "Confirmar";
            this.confirmFaltaBtn.UseVisualStyleBackColor = true;
            this.confirmFaltaBtn.Visible = false;
            this.confirmFaltaBtn.Click += new System.EventHandler(this.confirmFaltaBtn_Click);
            // 
            // eliminarBtn
            // 
            this.eliminarBtn.Font = new System.Drawing.Font("Arial", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.eliminarBtn.Location = new System.Drawing.Point(552, 191);
            this.eliminarBtn.Name = "eliminarBtn";
            this.eliminarBtn.Size = new System.Drawing.Size(90, 44);
            this.eliminarBtn.TabIndex = 226;
            this.eliminarBtn.Text = "Eliminar Registo";
            this.eliminarBtn.UseVisualStyleBackColor = true;
            this.eliminarBtn.Visible = false;
            this.eliminarBtn.Click += new System.EventHandler(this.button2_Click_1);
            // 
            // updateBtn
            // 
            this.updateBtn.Font = new System.Drawing.Font("Arial", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.updateBtn.Location = new System.Drawing.Point(666, 191);
            this.updateBtn.Name = "updateBtn";
            this.updateBtn.Size = new System.Drawing.Size(90, 44);
            this.updateBtn.TabIndex = 227;
            this.updateBtn.Text = "Update Registo";
            this.updateBtn.UseVisualStyleBackColor = true;
            this.updateBtn.Visible = false;
            this.updateBtn.Click += new System.EventHandler(this.button3_Click);
            // 
            // comboBoxtipoFalta
            // 
            this.comboBoxtipoFalta.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.comboBoxtipoFalta.Enabled = false;
            this.comboBoxtipoFalta.FormattingEnabled = true;
            this.comboBoxtipoFalta.Items.AddRange(new object[] {
            "Justificada",
            "Injustificada"});
            this.comboBoxtipoFalta.Location = new System.Drawing.Point(666, 134);
            this.comboBoxtipoFalta.Name = "comboBoxtipoFalta";
            this.comboBoxtipoFalta.Size = new System.Drawing.Size(91, 21);
            this.comboBoxtipoFalta.TabIndex = 228;
            this.comboBoxtipoFalta.SelectedIndexChanged += new System.EventHandler(this.comboBoxtipoFalta_SelectedIndexChanged);
            // 
            // cancelarBtn
            // 
            this.cancelarBtn.Font = new System.Drawing.Font("Arial", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cancelarBtn.Location = new System.Drawing.Point(552, 215);
            this.cancelarBtn.Name = "cancelarBtn";
            this.cancelarBtn.Size = new System.Drawing.Size(90, 44);
            this.cancelarBtn.TabIndex = 229;
            this.cancelarBtn.Text = "Cancelar";
            this.cancelarBtn.UseVisualStyleBackColor = true;
            this.cancelarBtn.Visible = false;
            this.cancelarBtn.Click += new System.EventHandler(this.button4_Click);
            // 
            // confirmUpdateBtn
            // 
            this.confirmUpdateBtn.Font = new System.Drawing.Font("Arial", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.confirmUpdateBtn.Location = new System.Drawing.Point(666, 215);
            this.confirmUpdateBtn.Name = "confirmUpdateBtn";
            this.confirmUpdateBtn.Size = new System.Drawing.Size(90, 44);
            this.confirmUpdateBtn.TabIndex = 230;
            this.confirmUpdateBtn.Text = "Confirmar";
            this.confirmUpdateBtn.UseVisualStyleBackColor = true;
            this.confirmUpdateBtn.Visible = false;
            this.confirmUpdateBtn.Click += new System.EventHandler(this.confirmUpdateBtn_Click);
            // 
            // button2
            // 
            this.button2.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.button2.Font = new System.Drawing.Font("Arial", 11F);
            this.button2.ForeColor = System.Drawing.Color.Black;
            this.button2.Location = new System.Drawing.Point(687, 8);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(57, 26);
            this.button2.TabIndex = 231;
            this.button2.Text = "Menu";
            this.button2.UseVisualStyleBackColor = false;
            this.button2.Click += new System.EventHandler(this.button2_Click_2);
            // 
            // Login
            // 
            this.Login.BackColor = System.Drawing.Color.Transparent;
            this.Login.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("Login.BackgroundImage")));
            this.Login.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.Login.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.Login.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Login.ForeColor = System.Drawing.Color.WhiteSmoke;
            this.Login.ImageAlign = System.Drawing.ContentAlignment.BottomLeft;
            this.Login.Location = new System.Drawing.Point(750, 5);
            this.Login.Name = "Login";
            this.Login.Size = new System.Drawing.Size(43, 33);
            this.Login.TabIndex = 232;
            this.Login.UseVisualStyleBackColor = false;
            this.Login.Click += new System.EventHandler(this.Login_Click);
            // 
            // NextPage
            // 
            this.NextPage.BackColor = System.Drawing.SystemColors.Control;
            this.NextPage.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.NextPage.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.NextPage.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.NextPage.Location = new System.Drawing.Point(716, 412);
            this.NextPage.Name = "NextPage";
            this.NextPage.Size = new System.Drawing.Size(77, 30);
            this.NextPage.TabIndex = 233;
            this.NextPage.Text = "Next";
            this.NextPage.UseVisualStyleBackColor = false;
            this.NextPage.Click += new System.EventHandler(this.NextPage_Click);
            // 
            // cancel_nota
            // 
            this.cancel_nota.Font = new System.Drawing.Font("Arial", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cancel_nota.Location = new System.Drawing.Point(375, 376);
            this.cancel_nota.Name = "cancel_nota";
            this.cancel_nota.Size = new System.Drawing.Size(90, 29);
            this.cancel_nota.TabIndex = 234;
            this.cancel_nota.Text = "Cancelar";
            this.cancel_nota.UseVisualStyleBackColor = true;
            this.cancel_nota.Visible = false;
            this.cancel_nota.Click += new System.EventHandler(this.button1_Click_1);
            // 
            // cancel_falta
            // 
            this.cancel_falta.Font = new System.Drawing.Font("Arial", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cancel_falta.Location = new System.Drawing.Point(375, 331);
            this.cancel_falta.Name = "cancel_falta";
            this.cancel_falta.Size = new System.Drawing.Size(90, 29);
            this.cancel_falta.TabIndex = 235;
            this.cancel_falta.Text = "Cancelar";
            this.cancel_falta.UseVisualStyleBackColor = true;
            this.cancel_falta.Visible = false;
            this.cancel_falta.Click += new System.EventHandler(this.button1_Click_2);
            // 
            // FormRegistos
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.ButtonHighlight;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.cancel_falta);
            this.Controls.Add(this.cancel_nota);
            this.Controls.Add(this.NextPage);
            this.Controls.Add(this.Login);
            this.Controls.Add(this.button2);
            this.Controls.Add(this.confirmUpdateBtn);
            this.Controls.Add(this.cancelarBtn);
            this.Controls.Add(this.comboBoxtipoFalta);
            this.Controls.Add(this.updateBtn);
            this.Controls.Add(this.eliminarBtn);
            this.Controls.Add(this.confirmFaltaBtn);
            this.Controls.Add(this.tipoFaltaCombo);
            this.Controls.Add(this.labelucfalta);
            this.Controls.Add(this.labeltipofalta);
            this.Controls.Add(this.labelnmecfalta);
            this.Controls.Add(this.ucfalta);
            this.Controls.Add(this.nmecfalta);
            this.Controls.Add(this.hideBtn);
            this.Controls.Add(this.filtros_btn);
            this.Controls.Add(this.confirmBtn);
            this.Controls.Add(this.label18);
            this.Controls.Add(this.label20);
            this.Controls.Add(this.label23);
            this.Controls.Add(this.id_falta);
            this.Controls.Add(this.label19);
            this.Controls.Add(this.id_nota);
            this.Controls.Add(this.notaBox);
            this.Controls.Add(this.label17);
            this.Controls.Add(this.label12);
            this.Controls.Add(this.label9);
            this.Controls.Add(this.label11);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.id_uc_Registo);
            this.Controls.Add(this.id_Aval_Registo);
            this.Controls.Add(this.nmecRegisto);
            this.Controls.Add(this.id_registo);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.labelucadd);
            this.Controls.Add(this.labelnotaadd);
            this.Controls.Add(this.labelnmecadd);
            this.Controls.Add(this.id_uc_nota);
            this.Controls.Add(this.nota_Nota);
            this.Controls.Add(this.NMEC_nota);
            this.Controls.Add(this.faltaBtn);
            this.Controls.Add(this.notaBtn);
            this.Controls.Add(this.labelCurso);
            this.Controls.Add(this.labelHorario);
            this.Controls.Add(this.labelNMEC);
            this.Controls.Add(this.labelEmail);
            this.Controls.Add(this.idCursoAluno);
            this.Controls.Add(this.idHorarioAluno);
            this.Controls.Add(this.nmecAluno);
            this.Controls.Add(this.emailAluno);
            this.Controls.Add(this.labelNome);
            this.Controls.Add(this.nomeAluno);
            this.Controls.Add(this.listRegistos);
            this.Controls.Add(this.labelDepf);
            this.Controls.Add(this.comboBoxDep);
            this.Controls.Add(this.comboBoxCurso);
            this.Controls.Add(this.labelcursof);
            this.Controls.Add(this.labelturmaf);
            this.Controls.Add(this.comboBoxTurma);
            this.Controls.Add(this.label8);
            this.Controls.Add(this.n_Alunos);
            this.Controls.Add(this.label15);
            this.Controls.Add(this.label16);
            this.Controls.Add(this.labelRegistos);
            this.Controls.Add(this.listAlunos);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "FormRegistos";
            this.Text = "FormRegistos";
            this.Load += new System.EventHandler(this.FormRegistos_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.TextBox n_Alunos;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.Label labelRegistos;
        private System.Windows.Forms.ListBox listAlunos;
        private System.Windows.Forms.Label labelDepf;
        private System.Windows.Forms.ComboBox comboBoxDep;
        private System.Windows.Forms.ComboBox comboBoxCurso;
        private System.Windows.Forms.Label labelcursof;
        private System.Windows.Forms.Label labelturmaf;
        private System.Windows.Forms.ComboBox comboBoxTurma;
        private System.Windows.Forms.ListBox listRegistos;
        private System.Windows.Forms.Label labelCurso;
        private System.Windows.Forms.Label labelHorario;
        private System.Windows.Forms.Label labelNMEC;
        private System.Windows.Forms.Label labelEmail;
        private System.Windows.Forms.TextBox idCursoAluno;
        private System.Windows.Forms.TextBox idHorarioAluno;
        private System.Windows.Forms.TextBox nmecAluno;
        private System.Windows.Forms.TextBox emailAluno;
        private System.Windows.Forms.Label labelNome;
        private System.Windows.Forms.TextBox nomeAluno;
        private System.Windows.Forms.Button notaBtn;
        private System.Windows.Forms.Button faltaBtn;
        private System.Windows.Forms.Label labelucadd;
        private System.Windows.Forms.Label labelnotaadd;
        private System.Windows.Forms.Label labelnmecadd;
        private System.Windows.Forms.TextBox id_uc_nota;
        private System.Windows.Forms.TextBox nota_Nota;
        private System.Windows.Forms.TextBox NMEC_nota;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.TextBox id_uc_Registo;
        private System.Windows.Forms.TextBox id_Aval_Registo;
        private System.Windows.Forms.TextBox nmecRegisto;
        private System.Windows.Forms.TextBox id_registo;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.Label label17;
        private System.Windows.Forms.Label label19;
        private System.Windows.Forms.TextBox id_nota;
        private System.Windows.Forms.TextBox notaBox;
        private System.Windows.Forms.Label label23;
        private System.Windows.Forms.TextBox id_falta;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Label label20;
        private System.Windows.Forms.Label label18;
        private System.Windows.Forms.Button confirmBtn;
        private System.Windows.Forms.Button filtros_btn;
        private System.Windows.Forms.Button hideBtn;
        private System.Windows.Forms.Label labelucfalta;
        private System.Windows.Forms.Label labeltipofalta;
        private System.Windows.Forms.Label labelnmecfalta;
        private System.Windows.Forms.TextBox ucfalta;
        private System.Windows.Forms.TextBox nmecfalta;
        private System.Windows.Forms.ComboBox tipoFaltaCombo;
        private System.Windows.Forms.Button confirmFaltaBtn;
        private System.Windows.Forms.Button eliminarBtn;
        private System.Windows.Forms.Button updateBtn;
        private System.Windows.Forms.ComboBox comboBoxtipoFalta;
        private System.Windows.Forms.Button cancelarBtn;
        private System.Windows.Forms.Button confirmUpdateBtn;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.Button Login;
        private System.Windows.Forms.Button NextPage;
        private System.Windows.Forms.Button cancel_nota;
        private System.Windows.Forms.Button cancel_falta;
    }
}